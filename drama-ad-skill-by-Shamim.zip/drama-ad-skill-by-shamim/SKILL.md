---
name: drama-ad-skill-by-shamim
description: Make drama-style story image ads end to end — Brief → Story → Script → Voices → Characters → Locations → Props → Shots — and do EVERY step yourself. Includes humanized voice samples per speaker, character sheets, locations, props and one opening frame per shot, all kept current on the project's own review website. Use this whenever someone wants a drama story ad, anime or cartoon story ad, testimonial-style skit, retargeting skit, "make a story ad like this video", or wants to turn a script into an animated story — even if they never say "VSL" or "Seedance". This skill covers image generation and humanized voice samples only; it does not generate video, audio songs or Suno music.
---

# drama ad skill by Shamim

One kind of ad: a short animated drama with spoken lines, built as a set of reviewable image frames
(character sheets, locations, props and one opening frame per shot). People watch a story to the end, and the
product shows up as the turning point of someone's life instead of as an ad.

## You do everything

The pipeline is always:

**Brief → Story → Script → Voices → Characters → Locations → Props → Shots**

You run the WHOLE list yourself, in that order, end to end. Do not stop between steps and do not ask for
approval at each one — do the work well, keep the project website current, and report at the end.
Stop only when:

1. Something essential is missing (the product itself, or who the ad is for) — ask just for that, then continue.
2. The user asks you to pause, or comments on something — fix what they flagged and continue.
3. A generation about to run would cost the user real credits (see Money rules) and is large or unusual.

Start from whatever the user gives you (a product photo, a logo, a rough idea, a reference video). Make the
creative choices yourself (pitch, story, look, voices) and say in one line what you chose. If the user names a
preference, their preference wins.

## Tools

Use the generation tools connected in this chat (image generation, speech generation). If there is no image
tool, the bundled `scripts/kie_*.sh` can call kie.ai with the user's **own** `KIE_API_KEY` from their environment
(see README). Never ask for a key in chat, never paste one into a file, never use anyone else's key.

## The project website (update after every step)

Every project folder gets its own review website (`index.html`, plain HTML/CSS/JS, no server). After each step:

1. Write the results into `studio.json` (format: `references/studio.md`) and set `review` to the step, the tab to
   open and one sentence on what to check.
2. Run `python3 scripts/studio_publish.py <project-folder>`. The open page refreshes by itself within a few seconds.

New project: `python3 scripts/new_project.py <parent-folder> "<project name>" [--aspect 9:16]` — it creates the
folders, starter `studio.json`, `studio.js` and `index.html`. Existing project without `index.html`: write a
`studio.json` from what's in the folder and run `studio_publish.py` on it.

The page is view-only: no generate or edit buttons. All work happens in the chat. The user can leave comments on
the page at any time and paste them into the chat (Copy all comments) — fix what they flagged and keep going.

## Money rules (read first)

Image and voice generation can cost the user real money (credit-billed tools like kie.ai), and they will be angry
if it is wasted.

- Before a credit-billed batch, state in one line what will run and the estimated cost, then proceed. Get a clear
  yes first only if the batch is large, unusual, or the balance is low (`scripts/kie_balance.sh` with kie.ai).
  With tools that don't bill the user per generation, just make the assets.
- Test one item before a full batch whenever a new look, model or prompt pattern is involved.
- Only generate what the pipeline needs. No bonus takes, no "let me try again to fix a small thing" retries, no
  variants. If a result is off, fix defects in the assets you must ship; flag taste-level doubts in the report
  instead of regenerating on your own.
- Run images in batches of about 6 at a time on kie.ai; bigger bursts hit rate limits and fail.
- When the user says stop, stop launching jobs. Let jobs already running finish and report them.

Cost reference (kie.ai, verify with the price endpoint): GPT Image 2 ≈ $0.05 per 2K image (10 credits).
A typical ad ≈ 40 images ≈ $2.

## Rules for every ad

- **No text in visuals.** Write "no text, no letters, no logos, no signage" into image prompts. The user adds
  all captions, disclaimers and end cards. The only exception is exact text the user asks for in a shot (a name in a book, a phone message).
- **Simple full sentences** in dialogue (about grade 3). No fragment stacks.
- **Claims:** only what the brief allows. No prices unless given, no superlatives ("most affordable", "best"),
  no "FDA/clinically approved" for compounded or unapproved products, no cure claims, no fake testimonials.
  Rephrase to something true and keep the punch (e.g. "Not with <Brand>." instead of "the cheapest").
- **Copying a reference video:** take the structure and the beats, write your own lines. Don't copy a race-coded or
  hateful dynamic; flag Meta risks (sexual themes, body shaming, before/after bodies) once in the report.
- Faces of scary or supernatural characters can stay hidden (hood + glowing eyes): friendlier for ads, and no lip sync to get wrong.
- This skill does **not** generate video, audio songs or Suno music. It produces the image frames, voice samples and
  prompts a user can take into their own editor or video tool.

## The steps (you do all of them)

### 1. Brief → `brief` (tab: Brief)

Product, audience, offer, format, off-limits claims, reference. Fill it from what the user gave you; for medical or
health products, lock the claims guardrails yourself (compounded products are never "FDA approved", no cure or
number promises, no prices, Rx Only respected). Ask only if the product or audience is missing.

### 2. Story → `story.pitches`, `story.chosen`, `story.beats` (tab: Story)

Write 2–3 pitches, pick the strongest one yourself (one line saying why; the user's pick always wins if they give
one), then lock the beats with their runtime shares. The user often wants it MORE dramatic than feels comfortable —
go there. End on a flipped callback of the opening's worst line.

### 3. Script → `script` (tab: Script)

Dialogue only, then stage directions in brackets. Every line is a full, simple sentence, with who says it. Plan the
daggers and the callback. Keep the user's wording when they edit it. Expect to fix flagged lines without rewriting
what they didn't flag.

### 4. Voices → `voices` (tab: Voices)

One fixed description per speaker (age, ethnicity, accent, pitch, pace, attitude) AND one generated **humanized
voice sample** per speaker (`file`: `voices/<key>.mp3`) with your speech generation tool — one DISTINCT voice per
speaker, matching the description (audition candidates and pick), speaking their own lines from the script (~10–15 s).
Every voice entry also carries a four-field prompt block the Voices tab shows, without a comment box:
**Camera & Physics** (delivery — pitch, pace, energy, accent), **Action & Visuals** (the character's look),
**Dialogue** (their lines from the script), **Prompt** (the description pasted into prompts + the sample file).
The Voices tab shows a labeled audio player for each character’s chosen voice next to its block. Do not show comment labels or textareas on either Voices or Shots.

### 5. Characters → `library` kind `character` (tab: Characters)

Lead sheet first (multi-view sheet: full body front / 3/4 / side / back plus expression close-ups, plain background,
no text), then the other characters; a changed version (after a transformation) is image-to-image from the first
sheet so the face matches. The sheet is the face lock for every later frame. Check the small details that betray
the audience (wrong ages, wrong rings, outfit continuity).

### 6. Locations → `library` kind `location` (tab: Locations)

Every location as empty background art, drawn in the story's style line. Mood words matter ("almost pitch black,
lit by low blood-red fire" beats "dark") — put them in the location's `extra` so every shot there gets them.
If sets keep coming out photoreal in an animated style, redraw them with a character sheet attached as a
style-only reference ("use the attached image ONLY as the art-style reference, do NOT draw the person from it").

### 7. Props → `library` kind `prop` (tab: Props)

Real product photos are props — never regenerate them; copy the product exactly from the user's photo whenever it
appears. Story items that must match across shots (a framed family photo, a letter, a phone screen) are generated
once and reused as references. Screens face the character; screen content is shown only as a hand-and-phone
close-up or over the shoulder, with the real screenshot attached.

### 8. Shots → `shots` (tab: Shots)

One row per shot in story order (id, dur, refs, voice, line, frame, action) and ONE opening frame per shot
(`frames/f<id>.png`) generated from that row plus its reference images. Every shot carries a four-field prompt
block the Shots tab shows, without a comment box: **Camera & Physics** (camera + physical staging),
**Action & Visuals** (what the frame shows, look and mood), **Dialogue** (speaker: line — or none),
**Prompt** (the full generation prompt, ready to copy into a video tool). Rules for every frame:

- The frame shows what its line literally says. Fix any frame that doesn't.
- Camera variety: say where the camera is (close-up of hands, over the shoulder, eye level, top-down, wide) and one
  clear physical action. No location twice in a row, no camera angle twice in a row.
- "Exactly two arms and two legs per person, normal-sized hands; each named character appears once."
- No text in visuals except exact user-requested text (`text` field), and then spelled exactly.

## References

- `references/dialogue-ads.md` — voices, sheets, sets, shots and frames.
- `references/production.md` — style, character sheets, sets, shot rules (image only).
- `references/kie-api.md` — kie.ai image API details.
- `references/studio.md` — `studio.json` format and the review website.
